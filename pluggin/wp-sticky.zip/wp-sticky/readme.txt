=== WP-Sticky ===
Contributors: GamerZ
Donate link: http://lesterchan.net/wordpress
Tags: sticky, post, announcement, sticky post, stick, important, adhesive
Requires at least: 2.7
Stable tag: trunk

Adds a sticky post feature to your WordPress's blog.

== Description ==

Modified from Adhesive by Owen Winkler.

All the information (general, changelog, installation, upgrade, usage) you need about this plugin can be found here: [WP-Sticky Readme](http://lesterchan.net/wordpress/readme/wp-sticky.html "WP-Sticky Readme").
It is the exact same readme.html is included in the zip package.

== Development Blog ==

[GaMerZ WordPress Plugins Development Blog](http://lesterchan.net/wordpress/ "GaMerZ WordPress Plugins Development Blog")

== Installation ==

[WP-Sticky Readme](http://lesterchan.net/wordpress/readme/wp-sticky.html "WP-Sticky Readme") (Installation Tab)

== Screenshots ==

[WP-Sticky Screenshots](http://lesterchan.net/wordpress/screenshots/browse/wp-sticky/ "WP-Sticky Screenshots")

== Frequently Asked Questions ==

[WP-Sticky Support Forums](http://forums.lesterchan.net/index.php?board=26.0 "WP-Sticky Support Forums")