<?php

$lang['profiler_benchmarks']	= 'BENCHMARKS';
$lang['profiler_queries']		= 'REQUETES';
$lang['profiler_post_data']		= 'DONNEES POST';
$lang['profiler_no_db']			= 'Le driver de la base de donn&eacute;es n\'est actuellement pas charg&eacute;';
$lang['profiler_no_queries']	= 'Aucune requ&ecirc;te n\'a &eacute;t&eacute; ex&eacute;cut&eacute;e';
$lang['profiler_no_post']		= 'Aucune donn&eacute;e POST n\'existe';

?>