<?php
/*
	Plugin Name: Trackback and Pingback Widget
	Plugin URI: http://en.michaeluno.jp/trackback-and-pingback-widget
	Description: Displays trackbacks and pingbacks which belong to the displayed page in a widget.
	Version: 1.0.1.1
	Author: miunosoft, Michael Uno
	Author URI: http://michaeluno.jp
	Text Domain: trackback-and-pingback-widget
	Domain Path: /lang
	Requirements: This plugin requires WordPress >= 3.0 and PHP >= 5.1.2

*/

// for admin page
add_filter( 'plugin_row_meta', array( new TrackbackAndPingbackWidget_Admin, 'EmbedLinks' ), 10, 2 );
class TrackbackAndPingbackWidget_Admin {
	function EmbedLinks( $arrLinks, $strFile ) {
		if ( $strFile != plugin_basename( __FILE__ ) ) return $arrLinks;
		
		// add links to the $arrLinks array.
		$arrLinks[] = '<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=J4UJHETVAZX34">' . __( 'Donate', 'trackback-and-pingback-widget' ) . '</a>';
		$arrLinks[] = '<a href="http://en.michaeluno.jp/contact/custom-order/?lang=' . ( WPLANG ? WPLANG : 'en' ) . '">' . __( 'Order custom plugin', 'trackback-and-pingback-widget' ) . '</a>';
		return $arrLinks;
	}  		
}

// register the widget 
add_action( 'widgets_init', 'TrackbackAndPingbackWidget' );
function TrackbackAndPingbackWidget() {
	return register_widget( 'TrackbackAndPingbackWidget' );	
}

class TrackbackAndPingbackWidget extends WP_Widget {
	public function __construct() {
		parent::__construct(
	 		'tackback_and_pingback_widget', 
			'Trackback and Pingback Widget', 
			array( 'description' => __( 'A widget to display trackbacks and pingbacks of the current page.', 'tackback-and-pingback-widget' ), ) // Args
		);
	}

    function form( $instance ) {
        $title = esc_attr( isset( $instance['title'] ) ? $instance['title'] : '' );
        $numitems = empty( $instance['numitems'] ) ? 0 : esc_attr( $instance['numitems'] );		// the number of items to show
        $order = empty( $instance['order'] ) ? 1 : esc_attr( $instance['order'] );		// whether the newsest comes first or the olderst comes first
		$arrOrders = array( array( 'label' => __( 'Newest First', 'tackback-and-pingback-widget' ), 'value' => 1 ),
						    array( 'label' => __( 'Oldest First', 'tackback-and-pingback-widget' ), 'value' => 2 ),
						);
		$renderdate = empty( $instance['renderdate'] ) ? 0 : esc_attr( $instance['renderdate'] );		// whether the date is rendered
		$style = empty( $instance['style'] ) ? 'ol' : esc_attr( $instance['style'] );		// sets the default to 1 if it is empty
		$arrStyles = array( array( 'label' => 'ol', 'value' => 'ol' ),
						    array( 'label' => 'ul', 'value' => 'ul' ),
						    array( 'label' => 'div', 'value' => 'div' )
						);
		$type = empty( $instance['type'] ) ? 'pings' : esc_attr( $instance['type'] );		// sets the default to 1 if it is empty
		$arrTypes = array( array( 'label' => __( 'Trackbacks and Pingbacks', 'tackback-and-pingback-widget' ), 'value' => 'pings' ),	// 'all', 'comment', 'trackback', 'pingback', or 'pings'.
						    array( 'label' => __( 'Comments', 'tackback-and-pingback-widget' ), 'value' => 'comment' ),
						    array( 'label' => __( 'Trackbacks', 'tackback-and-pingback-widget' ), 'value' => 'trackback' ),
						    array( 'label' => __( 'Pingbacks', 'tackback-and-pingback-widget' ), 'value' => 'pingback' ),
						    array( 'label' => __( 'All', 'tackback-and-pingback-widget' ), 'value' => 'all' )
						);		
        ?>
		<p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'tackback-and-pingback-widget'); ?> <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></label></p>
		<p><label for="<?php echo $this->get_field_id('numitems'); ?>"><?php _e('Number of tack/pingbacks to show ( set 0 to show all) :', 'tackback-and-pingback-widget' ); ?> <input class="" id="<?php echo $this->get_field_id('numitems'); ?>" name="<?php echo $this->get_field_name('numitems'); ?>" type="text" size="3" value="<?php echo $numitems; ?>" /></label></p>
		<p>
			<label for="<?php echo $this->get_field_id( 'order' ); ?>"><?php _e( 'Select Order:', 'tackback-and-pingback-widget' ); ?></label><br />
			<select name="<?php echo $this->get_field_name( 'order' ); ?>" id="<?php echo $this->get_field_id( 'order' ); ?>">
				<?php 
				foreach($arrOrders as $arrOrder) 
					echo '<option value="' . esc_attr( $arrOrder['value'] ) . '" ' . ( $arrOrder['value'] == $order ? 'selected="Selected"' : '' ) . '>'
						. $arrOrder['label'] 
						. '</option>';
				?>
			</select>
		</p>
		<p>
			<input id="<?php echo $this->get_field_id('renderdate'); ?>" name="<?php echo $this->get_field_name('renderdate'); ?>" type="checkbox" value="1" <?php if ( $renderdate ) echo 'checked="checked"'; ?>/>
			<label for="<?php echo $this->get_field_id('renderdate'); ?>"><?php _e('Display item date?'); ?></label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'style' ); ?>"><?php _e( 'Enclosing HTML Tag:', 'tackback-and-pingback-widget' ); ?></label><br />
			<select name="<?php echo $this->get_field_name( 'style' ); ?>" id="<?php echo $this->get_field_id( 'style' ); ?>">
				<?php 
				foreach( $arrStyles as $arrStyle ) 
					echo '<option value="' . esc_attr( $arrStyle['value'] ) . '" ' . ( $arrStyle['value'] == $style ? 'selected="Selected"' : '' ) . '>'
						. $arrStyle['label'] 
						. '</option>';
				?>
			</select>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'type' ); ?>"><?php _e( 'Type:', 'tackback-and-pingback-widget' ); ?></label><br />
			<select name="<?php echo $this->get_field_name( 'type' ); ?>" id="<?php echo $this->get_field_id( 'type' ); ?>">
				<?php 
				foreach( $arrTypes as $arrType ) 
					echo '<option value="' . esc_attr( $arrType['value'] ) . '" ' . ( $arrType['value'] == $type ? 'selected="Selected"' : '' ) . '>'
						. $arrType['label'] 
						. '</option>';
				?>
			</select>
		</p>	
        <?php
    }

    function update( $new_instance, $old_instance ) {
        $new_instance['title'] = strip_tags( $new_instance['title'] );
        $new_instance['numitems'] = strip_tags( $new_instance['numitems'] );
        $new_instance['order'] = strip_tags( $new_instance['order'] );
        $new_instance['renderdate'] = strip_tags( $new_instance['renderdate'] );
        $new_instance['style'] = strip_tags( $new_instance['style'] );
        $new_instance['type'] = strip_tags( $new_instance['type'] );
        return $new_instance;
    }

    function widget( $args, $instance ) {
		/*
		 * The method which actually outputs the widget contents
		 * */
		
		/*
		 * If the current post is protected by a password and
		 * the visitor has not yet entered the password we will
		 * return early without loading the comments.
		 */
		if ( post_password_required() ) return;	
		
		// check the number of trackback/pingback comments
		if ( $this->CountTrackandpingbacks() == 0 ) return;
		
		// options
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		$numitems = apply_filters( 'widget_title', $instance['numitems'] );
		$order = apply_filters( 'widget_title', $instance['order'] );
		$renderdate = apply_filters( 'widget_title', $instance['renderdate'] );
		
		$style = apply_filters( 'widget_title', $instance['style'] );	// added since 1.0.1
		$type = apply_filters( 'widget_title', $instance['type'] );		// added since 1.0.1
		
		?>
		<h3 class="widget-title"><?php echo $title; ?></h3>
		<<?php echo $style; ?> class="commentlist">	
			<?php $this->wp_list_comments(	array( 'callback' => array( $this, 'RenderComments' ), 'type' => $type, 'style' => $style, 'renderdate' => $renderdate )
										  , null
										  , array( 'order' => $order, 'numitems' => $numitems )
										  ); 
			?>
		</<?php echo $style; ?>><!-- .commentlist -->		 
		<?php
    }

	function RenderComments( $comment, $args, $depth ) {
// print '<pre>' . print_r($args, true) . '</pre>';		
// print '<hr />';
		
		$strTag = ( $args['style'] == 'div' ) ? 'div' : 'li';
		
		$GLOBALS['comment'] = $comment;
		switch ( $comment->comment_type ) :
			case 'pingback' :
			case 'trackback' :
			// Display trackbacks differently than normal comments.
		?>
		<<?php echo $strTag . ' '; comment_class(); ?> id="comment-<?php comment_ID(); ?>">
			<?php 
			comment_author_link(); 
			if ( $args['renderdate'] ) printf( ' - <a href="%1$s"><time datetime="%2$s">%3$s</time></a>',
												esc_url( get_comment_link( $comment->comment_ID ) ),
												get_comment_time( 'c' ),
												/* translators: 1: date, 2: time */
												sprintf( __( '%1$s at %2$s', 'tackback-and-pingback-widget' ), get_comment_date(), get_comment_time() )
										);			
			edit_comment_link( ' ' . __( '(Edit)', 'tackback-and-pingback-widget' ), '<span class="edit-link">', '</span>' );
			?>			
		<?php
				break;
			default :
			// Proceed with normal comments.
			global $post;
		?>
		<<?php echo $strTag . ' '; comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
			<article id="comment-<?php comment_ID(); ?>" class="comment">
				<header class="comment-meta comment-author vcard">
					<?php
						echo get_avatar( $comment, 44 );
						printf( '<cite class="fn">%1$s %2$s</cite>',
							get_comment_author_link(),
							// If current post author is also comment author, make it known visually.
							( $comment->user_id === $post->post_author ) ? '<span> ' . __( 'Post author', 'tackback-and-pingback-widget' ) . '</span>' : ''
						);
						printf( '<a href="%1$s"><time datetime="%2$s">%3$s</time></a>',
							esc_url( get_comment_link( $comment->comment_ID ) ),
							get_comment_time( 'c' ),
							/* translators: 1: date, 2: time */
							sprintf( __( '%1$s at %2$s', 'tackback-and-pingback-widget' ), get_comment_date(), get_comment_time() )
						);
					?>
				</header><!-- .comment-meta -->

				<?php if ( '0' == $comment->comment_approved ) : ?>
					<p class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.', 'tackback-and-pingback-widget' ); ?></p>
				<?php endif; ?>

				<section class="comment-content comment">
					<?php comment_text(); ?>
					<?php edit_comment_link( __( 'Edit', 'tackback-and-pingback-widget' ), '<p class="edit-link">', '</p>' ); ?>
				</section><!-- .comment-content -->

				<div class="reply">
					<?php comment_reply_link( array_merge( $args, array( 'reply_text' => __( 'Reply', 'tackback-and-pingback-widget' ), 'after' => ' <span>&darr;</span>', 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
				</div><!-- .reply -->
			</article><!-- #comment-## -->
		<?php
			break;
		endswitch; // end comment_type check		
	}
	
	function CountTrackandpingbacks() {
		global $wp_query;		
		if ( empty($wp_query->comments) ) return 0;
		$_comments = $wp_query->comments_by_type['pings'];
		return count( $_comments );
	}
	
	function wp_list_comments($args = array(), $comments = null, $arrArgs = array() ) {
		global $wp_query, $comment_alt, $comment_depth, $comment_thread_alt, $overridden_cpage, $in_comment_loop;

		$in_comment_loop = true;

		$comment_alt = $comment_thread_alt = 0;
		$comment_depth = 1;

		$defaults = array('walker' => null, 'max_depth' => '', 'style' => 'ul', 'callback' => null, 'end-callback' => null, 'type' => 'all',
			'page' => '', 'per_page' => '', 'avatar_size' => 32, 'reverse_top_level' => null, 'reverse_children' => '');
	
		// $defaults['reverse_top_level'] = $arrArgs['order'] == 1 ? false : true;	// 1: new ones come first, 2: old ones come first
		
		$r = wp_parse_args( $args, $defaults );

		// Figure out what comments we'll be looping through ($_comments)
		if ( null !== $comments ) {
			$comments = (array) $comments;
			if ( empty($comments) )
				return;
			if ( 'all' != $r['type'] ) {
				$comments_by_type = separate_comments($comments);
				if ( empty($comments_by_type[$r['type']]) )
					return;
				$_comments = $comments_by_type[$r['type']];
			} else {
				$_comments = $comments;
			}
		} else {
			if ( empty($wp_query->comments) )
				return;
			if ( 'all' != $r['type'] ) {
				if ( empty($wp_query->comments_by_type) )
					$wp_query->comments_by_type = separate_comments($wp_query->comments);
				if ( empty($wp_query->comments_by_type[$r['type']]) )
					return;
				$_comments = $wp_query->comments_by_type[$r['type']];
			} else {
				$_comments = $wp_query->comments;
			}
		}

		if ( '' === $r['per_page'] && get_option('page_comments') )
			$r['per_page'] = get_query_var('comments_per_page');

		if ( empty($r['per_page']) ) {
			$r['per_page'] = 0;
			$r['page'] = 0;
		}

		if ( '' === $r['max_depth'] ) {
			if ( get_option('thread_comments') )
				$r['max_depth'] = get_option('thread_comments_depth');
			else
				$r['max_depth'] = -1;
		}

		if ( '' === $r['page'] ) {
			if ( empty($overridden_cpage) ) {
				$r['page'] = get_query_var('cpage');
			} else {
				$threaded = ( -1 != $r['max_depth'] );
				$r['page'] = ( 'newest' == get_option('default_comments_page') ) ? get_comment_pages_count($_comments, $r['per_page'], $threaded) : 1;
				set_query_var( 'cpage', $r['page'] );
			}
		}
		// Validation check
		$r['page'] = intval($r['page']);
		if ( 0 == $r['page'] && 0 != $r['per_page'] )
			$r['page'] = 1;

		if ( null === $r['reverse_top_level'] )
			$r['reverse_top_level'] = ( 'desc' == get_option('comment_order') );

		extract( $r, EXTR_SKIP );

		if ( empty( $walker ) ) $walker = new Walker_TrackandPingbacks( $arrArgs );
			
		// render the elements
		$walker->paged_walk( $_comments, $max_depth, $page, $per_page, $r );

		$wp_query->max_num_comment_pages = $walker->max_pages;

		$in_comment_loop = false;
	}	
} // End class

class Walker_TrackandPingbacks extends Walker_comment {
	
		function __construct( $arrArgs ) {
			$this->arrArgs = $arrArgs;			
		}
	
		function SortByCommentDate( $a, $b ) {
			/*
			 * usort callback function
			 * */
		  if(  $a->comment_date ==  $b->comment_date ){ return 0 ; } 
		  return ($a->comment_date > $b->comment_date) ? -1 : 1;
		} 
	
		function paged_walk( $elements, $max_depth, $page_num, $per_page ) {

		/* sanity check */
		if ( empty($elements) || $max_depth < -1 )
			return '';
			
		/*
		 * Sort the object by [comment_date]
		 * 
		[0] => stdClass Object
        (
            [comment_ID] => 20
            [comment_post_ID] => 467
            [comment_author] => Ejecuta rápidamente tus programas con tu ratón usando Quick Menu
            [comment_author_email] => 
            [comment_author_url] => http://techtastico.com/post/ejecuta-rapidamente-tus-programas-con-tu-raton-usando-quick-menu/
            [comment_author_IP] => 69.73.174.242
            [comment_date] => 2011-07-23 14:46:32
            [comment_date_gmt] => 2011-07-23 05:46:32
            [comment_content] => [...] os directos y te gusta tener todos tus programas en un clic entonces te recomiendo utilizar Quick Menu. [...]
            [comment_karma] => 0
            [comment_approved] => 1
            [comment_agent] => 
            [comment_type] => pingback
            [comment_parent] => 0
            [user_id] => 0
        )		
		* */ 

		// options
		$arrArgs = $this->arrArgs;
		
		// sort by date
		usort( $elements, array( $this, 'SortByCommentDate' ) );	

		// limit the number of items to show
		// if ( $arrArgs['numitems'] != 0 ) 
		if ( $arrArgs['numitems'] != 0 )
			$elements = array_slice( (array) $elements, ( $arrArgs['order'] == 1 ) ? 0 : ( -1 * $arrArgs['numitems'] ), $arrArgs['numitems'] );

		// decide whether new ones come first or old ones come first		
		if ( $arrArgs['order'] == 1 ) $elements = array_reverse( $elements );

		$args = array_slice( func_get_args(), 4 );
		$output = '';

		$id_field = $this->db_fields['id'];
		$parent_field = $this->db_fields['parent'];

		$count = -1;
		if ( -1 == $max_depth )
			$total_top = count( $elements );
		if ( $page_num < 1 || $per_page < 0  ) {
			// No paging
			$paging = false;
			$start = 0;
			if ( -1 == $max_depth )
				$end = $total_top;
			$this->max_pages = 1;
		} else {
			$paging = true;
			$start = ( (int)$page_num - 1 ) * (int)$per_page;
			$end   = $start + $per_page;
			if ( -1 == $max_depth )
				$this->max_pages = ceil($total_top / $per_page);
		}

		// flat display
		if ( -1 == $max_depth ) {
			if ( !empty($args[0]['reverse_top_level']) ) {
				$elements = array_reverse( $elements );
				$oldstart = $start;
				$start = $total_top - $end;
				$end = $total_top - $oldstart;
			}

			$empty_array = array();
			foreach ( $elements as $e ) {
				$count++;
				if ( $count < $start )
					continue;
				if ( $count >= $end )
					break;
				$this->display_element( $e, $empty_array, 1, 0, $args, $output );
			}
			return $output;
		}

		/*
		 * separate elements into two buckets: top level and children elements
		 * children_elements is two dimensional array, eg.
		 * children_elements[10][] contains all sub-elements whose parent is 10.
		 */
		$top_level_elements = array();
		$children_elements  = array();
		foreach ( $elements as $e) {
			if ( 0 == $e->$parent_field )
				$top_level_elements[] = $e;
			else
				$children_elements[ $e->$parent_field ][] = $e;
		}

		$total_top = count( $top_level_elements );
		if ( $paging )
			$this->max_pages = ceil($total_top / $per_page);
		else
			$end = $total_top;

		if ( !empty($args[0]['reverse_top_level']) ) {
			$top_level_elements = array_reverse( $top_level_elements );
			$oldstart = $start;
			$start = $total_top - $end;
			$end = $total_top - $oldstart;
		}
		if ( !empty($args[0]['reverse_children']) ) {
			foreach ( $children_elements as $parent => $children )
				$children_elements[$parent] = array_reverse( $children );
		}

		foreach ( $top_level_elements as $e ) {
			$count++;

			//for the last page, need to unset earlier children in order to keep track of orphans
			if ( $end >= $total_top && $count < $start )
					$this->unset_children( $e, $children_elements );

			if ( $count < $start )
				continue;

			if ( $count >= $end )
				break;

			$this->display_element( $e, $children_elements, $max_depth, 0, $args, $output );
		}

		if ( $end >= $total_top && count( $children_elements ) > 0 ) {
			$empty_array = array();
			foreach ( $children_elements as $orphans )
				foreach( $orphans as $op )
					$this->display_element( $op, $empty_array, 1, 0, $args, $output );
		}

		return $output;
	}
}